package br.ufal.ic.p2.shopping;

import java.util.ArrayList;

public class ShoppingCart {
    
    private int customerID;

    private ArrayList products;

    public ShoppingCart(int customerID) {
        this.customerID = customerID;
        this.products = new ArrayList();
    }

    public void addProducts(Product product){
        this.products.add(product);
    }

    public String getContent(){
        for (int i = 0; i < this.products.size(); i++){
            Product product = (Product)this.products.get(i);
            String data = (product.getName() + ", "+ product.getPrice());
            System.out.println(data);
        }
        return "";
    }

}
