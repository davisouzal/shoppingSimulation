package br.ufal.ic.p2.shopping;

public class Main {
    public static void main(String[] args) {
        Product product1 = new Product( "Camisa do CRB", 0.5);
        Product product2 = new Product( "Camisa do CSA", 500);

        ShoppingCart sc = new ShoppingCart(1);
        sc.addProducts(product1);
        sc.addProducts(product2);

        sc.getContent();
    }
}
